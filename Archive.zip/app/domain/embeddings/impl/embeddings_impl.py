"""Persistent ChromaDB client and collection accessor."""

from __future__ import annotations

from typing import Dict, Optional

import chromadb
from app.domain.embeddings.base.vector_store_base import VectorStoreBase, VectorCollection
from chromadb.config import Settings

class EmbeddingsImpl(VectorStoreBase):
    """Manages a persistent Chroma client and cached collections."""

    def __init__(self, path: str = "./chroma_memory", settings: Optional[Settings] = None) -> None:
        """Create a persistent client and preload default collection."""
        self._settings = settings or Settings(anonymized_telemetry=False)
        self._client = chromadb.PersistentClient(path=str(path), settings=self._settings)
        self._default_name = "agent_memory"
        self._cache: Dict[str, VectorCollection] = {}
        self.collection = self.get_collection(self._default_name)

    def get_client(self):
        """Expose the underlying Chroma client so other domains reuse it."""
        return self._client

    def get_collection(self, name: Optional[str] = None) -> VectorCollection:
        """Return a cached or newly created Chroma collection by name."""
        coll_name = name or self._default_name
        if coll_name in self._cache:
            return self._cache[coll_name]

        collection = self._client.get_or_create_collection(name=coll_name)
        self._cache[coll_name] = collection
        return collection
