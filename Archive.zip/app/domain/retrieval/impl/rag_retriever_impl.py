# rag_retriever_impl.py
from __future__ import annotations
from typing import List, Optional

from chromadb import PersistentClient
from llama_index.core import VectorStoreIndex, Settings
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.llms.ollama import Ollama

from app.config import CFG


class RagRetrieverImpl:
    def __init__(self) -> None:
        self._index: Optional[VectorStoreIndex] = None
        self._client: Optional[PersistentClient] = None

        # LLM + embeddings from manifest
        llm = Ollama(
            model=CFG.models.main.model_id,
            temperature=CFG.models.main.temperature,
            # Some LlamaIndex builds ignore this; harmless if unused:
            context_window=CFG.models.main.max_tokens,
        )
        embed = HuggingFaceEmbedding(model_name=CFG.retrieval.embeddings_model)

        # Global settings for LlamaIndex
        Settings.llm = llm
        Settings.embed_model = embed

    def _get_index(self) -> VectorStoreIndex:
        if self._index is None:
            # 1) Persistent Chroma client at your configured path
            self._client = PersistentClient(path=str(CFG.paths.vector_store_dir))

            # 2) Resolve a real collection object (NOT a string)
            collection = self._client.get_or_create_collection(
                name=CFG.memory.collection_name,
                metadata={"hnsw:space": "cosine"},  # optional; pick your metric
            )

            # 3) Wrap the collection with LlamaIndex vector store
            vector_store = ChromaVectorStore(chroma_collection=collection)

            # 4) Build the index on top of the vector store
            self._index = VectorStoreIndex.from_vector_store(vector_store=vector_store)

        return self._index

    def retrieve(self, query: str, *, top_k: int = 4) -> List[str]:
        nodes = self._get_index().as_retriever(similarity_top_k=top_k).retrieve(query)
        chunks: List[str] = []
        for n in nodes:
            node = getattr(n, "node", n)
            text = (
                (getattr(node, "get_content", None) and node.get_content())
                or (getattr(node, "get_text", None) and node.get_text())
                or getattr(node, "text", None)
                or str(node)
            )
            if text:
                chunks.append(str(text))
        return chunks

    def query(self, question: str, *, top_k: int = 4) -> str:
        engine = self._get_index().as_query_engine(
            similarity_top_k=top_k,
            response_mode="compact",
        )
        return str(engine.query(question))
