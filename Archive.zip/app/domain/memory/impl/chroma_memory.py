# app/domain/memory/impl/chroma_memory.py
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import List

from app.common.decorators.errors import catch_and_log_errors
from app.config import CFG
from app.domain.embeddings.base.vector_store_base import VectorStoreBase, VectorCollection
from app.domain.embeddings.impl.embeddings_impl import EmbeddingsImpl
from app.domain.embeddings.utils.embeddings_utils import get_cached_embedding
from app.domain.memory.base.memory_base import MemoryBase

class MemoryImpl(MemoryBase):
    """Semantic memory backed by a Chroma collection (DI only)."""

    def __init__(self, *, store: VectorStoreBase, collection_name: str = "agent_memory", window_size: int = 3) -> None:
        self.window_size = int(window_size)
        self.store = store                                 # <-- use injected store
        self.collection: VectorCollection = store.get_collection(collection_name)

    @catch_and_log_errors()
    def store_interaction(self, user_input: str, agent_response: str) -> None:
        combined_text = f"User: {user_input}\nAgent: {agent_response}"
        embedding = get_cached_embedding(combined_text)
        self.collection.add(
            documents=[combined_text],
            embeddings=[embedding],
            ids=[str(uuid.uuid4())],
            metadatas=[{"timestamp": datetime.now(timezone.utc).isoformat()}],
        )

    @catch_and_log_errors(default_return=[])
    def retrieve_context(self, query: str) -> List[str]:
        query_embedding = get_cached_embedding(query)
        results = self.collection.query(query_embeddings=[query_embedding], n_results=self.window_size)
        return results.get("documents", [[]])[0]
