"""
config.py

Loads and centralizes all runtime configuration needed for the agent system,
including:
- Prompt templates from modular YAML files
- Manifest-based toggles (eval, retrieval, thresholds, etc.)
- Model selection and memory initialization

This module is imported by various components and provides shared constants.

Author: Ricardo Arcifa
Created: 2025-02-03
"""

from pathlib import Path

import yaml

from app.lib.embeddings.memory_manager import MemoryManager
from app.enums.eval import EvalConfigKey, RetrievalConfigKey
from app.enums.manifest import ManifestConfigKey
from app.enums.model import ModelConfigKey
from app.enums.prompts import PromptConfigKey
from app.lib.tools.registries.prompt_registry import PromptRegistry

# === Paths ===
MANIFEST_PATH = Path("manifest.yaml")
PROMPT_DIR = "prompts"

# === Load and parse manifest.yaml ===
with MANIFEST_PATH.open() as f:
    manifest_cfg = yaml.safe_load(f)

# === Initialize prompt registry ===
prompt_registry = PromptRegistry(PROMPT_DIR)

# === Load modular YAML prompts ===
system = prompt_registry.get("agent/system")
planner = prompt_registry.get("agent/planner")
qa = prompt_registry.get("agent/qa")
helpfulness = prompt_registry.get("eval/helpfulness")
grounding = prompt_registry.get("eval/grounding")
relevance = prompt_registry.get("reviewer/relevance")

# === Extract system prompt values ===
system_template = system[PromptConfigKey.TEMPLATE]

# === Extract planner prompt values ===
planner_template = planner[PromptConfigKey.TEMPLATE]

# === Extract QA prompt details ===
qa_template = qa[PromptConfigKey.TEMPLATE]
qa_template_name = qa[PromptConfigKey.TEMPLATE_NAME]
qa_prompt_version = qa[PromptConfigKey.VERSION]
qa_name = qa[PromptConfigKey.NAME]

# === Eval-specific templates ===
helpfulness_template = helpfulness[PromptConfigKey.TEMPLATE]
grounding_template = grounding[PromptConfigKey.TEMPLATE]
relevance_template = relevance[PromptConfigKey.TEMPLATE]

# === Manifest-based runtime config ===
model = manifest_cfg[ManifestConfigKey.MODEL][ModelConfigKey.MODEL_ID]
use_eval = manifest_cfg.get(ManifestConfigKey.EVAL, {}).get(
    EvalConfigKey.ENABLED, False
)
retrieval_enabled = manifest_cfg.get(ManifestConfigKey.RETRIEVAL, {}).get(
    RetrievalConfigKey.ENABLED, False
)
thresholds = manifest_cfg.get(ManifestConfigKey.EVAL, {}).get(
    ManifestConfigKey.THRESHOLDS, {}
)

# === Singleton memory manager ===
memory = MemoryManager(manifest_cfg[ManifestConfigKey.MEMORY])
