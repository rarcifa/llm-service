"""
errors.py

Defines standardized error type enums for categorizing agent-related failures.
Used to label and return consistent error codes across agent pipeline components.

Author: Ricardo Arcifa
Created: 2025-02-03
"""

from enum import StrEnum


class ErrorType(StrEnum):
    """
    Enum representing different categories of agent errors.

    Attributes:
        AGENT (str): General agent processing error.
    """

    AGENT = "Agent error"
